package scs;

public class PrimeLogic {
	public static String checkPrime(int num)
	   {
		     String s = "prime";
			  int i;
			  for(i=2;i<num;i++)
			  {
				  if(num%i==0)
				  {
					 s = "not prime";
					 break;
				  }
			  }
			  if(num==i)
			  {
				  s = " prime";
			  }
			  
			  return s;
	   }
}
