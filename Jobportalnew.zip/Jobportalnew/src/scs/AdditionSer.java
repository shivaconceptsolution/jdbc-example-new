package scs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ram")
public class AdditionSer extends HttpServlet {
  
  public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException
  {
	  res.setContentType("text/html");
	  PrintWriter out =  res.getWriter();
	  out.print("Result is <br><br>");
	  int num = Integer.parseInt(req.getParameter("txtnum1"));
	  out.print("result is "+PrimeLogic.checkPrime(num));
  }
  
   
  
}
